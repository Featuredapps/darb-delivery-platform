import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';

app.disable('x-powered-by');

app.get('/api/v1/healthz', (_req, res) => {
  res.json({ status: 'ok' });
});

app.get(['/', '/index.html'], (_req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.get(['/admin', '/admin/', '/admin/index.html'], (_req, res) => {
  res.sendFile(path.join(__dirname, 'admin-web', 'index.html'));
});

app.use('/admin', express.static(path.join(__dirname, 'admin-web')));

app.use((_req, res) => {
  res
    .status(404)
    .type('html')
    .send(
      '<!doctype html><html lang="ar" dir="rtl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>الصفحة غير موجودة | دَرْب</title><body style="font-family:Tahoma,Arial;background:#f6f7f2;color:#102b26;display:grid;place-items:center;min-height:90vh;text-align:center"><main><h1>هذه الصفحة غير موجودة</h1><p>قد يكون الرابط غير صحيح أو تم نقل الصفحة.</p><a href="/">العودة إلى موقع دَرْب</a></main></body></html>',
    );
});

app.listen(PORT, HOST, () => {
  console.log(`DARB web server listening on http://${HOST}:${PORT}`);
});
