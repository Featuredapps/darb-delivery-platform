part of 'app_shell.dart';

String _localizedAdminCityName(dynamic city) {
  if (city is! Map) return '';
  final names = city['names'] as List? ?? const [];
  final locale = darbLocale.value.languageCode;
  for (final item in names) {
    if (item is Map && item['locale'] == locale && item['name'] != null) {
      return item['name'].toString();
    }
  }
  for (final item in names) {
    if (item is Map && item['locale'] == 'ar' && item['name'] != null) {
      return item['name'].toString();
    }
  }
  if (names.isNotEmpty && names.first is Map && names.first['name'] != null) {
    return names.first['name'].toString();
  }
  return city['code']?.toString() ?? '';
}

String _localizedAdminVendorName(dynamic vendor) {
  if (vendor is! Map) return '';
  final translations = vendor['translations'] as List? ?? const [];
  final locale = darbLocale.value.languageCode;
  for (final item in translations) {
    if (item is Map && item['locale'] == locale && item['name'] != null) {
      return item['name'].toString();
    }
  }
  for (final item in translations) {
    if (item is Map && item['locale'] == 'ar' && item['name'] != null) {
      return item['name'].toString();
    }
  }
  if (translations.isNotEmpty &&
      translations.first is Map &&
      translations.first['name'] != null) {
    return translations.first['name'].toString();
  }
  return '';
}

class AdminOrders extends StatefulWidget {
  const AdminOrders({super.key});

  @override
  State<AdminOrders> createState() => _AdminOrdersState();
}

class _AdminOrdersState extends State<AdminOrders> {
  static const List<String> _statuses = [
    '',
    'PENDING',
    'ACCEPTED',
    'PREPARING',
    'READY',
    'ASSIGNED',
    'PICKED_UP',
    'DELIVERED',
    'CANCELLED',
  ];

  static const List<String> _types = [
    '',
    'VENDOR_ORDER',
    'PEER_DELIVERY',
  ];

  bool loading = true;
  String? error;
  String selectedStatus = '';
  String selectedType = '';
  int page = 1;
  int pages = 1;
  int total = 0;
  int _loadGeneration = 0;
  List<dynamic> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load({int? targetPage}) async {
    final nextPage = targetPage ?? page;
    final generation = ++_loadGeneration;
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
        page = nextPage;
      });
    }
    try {
      final query = <String>['page=$nextPage', 'limit=20'];
      if (selectedStatus.isNotEmpty) query.add('status=$selectedStatus');
      if (selectedType.isNotEmpty) query.add('type=$selectedType');
      final response = await Api.instance.get('/admin/orders?${query.join('&')}');
      if (generation != _loadGeneration || !mounted) return;
      if (response is! Map) {
        throw ApiException(dt('تعذر تحديث القائمة'));
      }
      setState(() {
        items = (response['items'] as List?) ?? const [];
        total = (response['total'] as num?)?.toInt() ?? items.length;
        page = (response['page'] as num?)?.toInt() ?? nextPage;
        final rawPages = (response['pages'] as num?)?.toInt() ?? 1;
        pages = rawPages < 1 ? 1 : rawPages;
        error = null;
      });
    } catch (e) {
      if (generation == _loadGeneration && mounted) {
        setState(() => error = e.toString());
      }
    } finally {
      if (generation == _loadGeneration && mounted) {
        setState(() => loading = false);
      }
    }
  }

  String _statusLabel(String status, {required bool peer}) {
    switch (status) {
      case '':
        return dt('الكل');
      case 'PENDING':
        return peer ? dt('بانتظار العروض') : dt('بانتظار التأكيد');
      case 'ACCEPTED':
        return dt('تم قبول الطلب');
      case 'PREPARING':
        return dt('قيد التحضير');
      case 'READY':
        return dt('جاهز للاستلام');
      case 'ASSIGNED':
        return dt('تم تعيين سائق');
      case 'PICKED_UP':
        return dt('تم الاستلام');
      case 'DELIVERED':
        return dt('تم التسليم');
      case 'CANCELLED':
        return dt('ملغي');
      default:
        return status;
    }
  }

  DarbTone _statusTone(String status) => switch (status) {
        'DELIVERED' => DarbTone.success,
        'CANCELLED' => DarbTone.danger,
        'PENDING' => DarbTone.warning,
        _ => DarbTone.info,
      };

  int _progressStep(String status, {required bool peer}) {
    if (peer) {
      return switch (status) {
        'PENDING' => 0,
        'ASSIGNED' => 1,
        'PICKED_UP' => 2,
        'DELIVERED' => 3,
        _ => 0,
      };
    }
    return switch (status) {
      'PENDING' => 0,
      'ACCEPTED' => 1,
      'PREPARING' => 2,
      'READY' => 3,
      'ASSIGNED' => 4,
      'PICKED_UP' => 5,
      'DELIVERED' => 6,
      _ => 0,
    };
  }

  String _typeLabel(String type) => switch (type) {
        'VENDOR_ORDER' => dt('طلب من متجر'),
        'PEER_DELIVERY' => dt('توصيل غرض مستقل'),
        _ => dt('الكل'),
      };

  void _showOrderDetails(dynamic row) {
    final status = row['status']?.toString() ?? '';
    final peer = row['type'] == 'PEER_DELIVERY';
    final currency = row['currency']?.toString() ?? '';
    final customer = row['customer'] as Map? ?? const {};
    final driver = row['driver'] as Map?;
    final driverUser = driver?['user'] as Map?;
    final vendorName = _localizedAdminVendorName(row['vendor']);
    final cityName = _localizedAdminCityName(row['city']);
    final notes = row['notes']?.toString().trim() ?? '';

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${dt('تفاصيل الطلب')} • ${row['orderNumber'] ?? row['id'] ?? ''}',
                      style: TextStyle(
                        color: DarbColors.ink,
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  DarbStatusBadge(
                    label: _statusLabel(status, peer: peer),
                    tone: _statusTone(status),
                    pulse: status == 'ASSIGNED' || status == 'PICKED_UP',
                  ),
                ],
              ),
              if (status != 'CANCELLED') ...[
                const SizedBox(height: 16),
                Text(
                  dt('مسار حالة الطلب'),
                  style: TextStyle(
                    color: DarbColors.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 8),
                DarbStepProgress(
                  totalSteps: peer ? 4 : 7,
                  currentStep: _progressStep(status, peer: peer),
                ),
              ],
              const SizedBox(height: 16),
              DarbSurfaceCard(
                padding: const EdgeInsets.all(14),
                backgroundColor: DarbColors.surfaceAlt,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _detailLine(
                      dt('العميل'),
                      '${customer['name'] ?? dt('غير محدد')} ${customer['phone'] != null ? '• ${customer['phone']}' : ''}'
                          .trim(),
                    ),
                    if (cityName.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      _detailLine(dt('المدينة'), cityName),
                    ],
                    if (vendorName.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      _detailLine(dt('التاجر'), vendorName),
                    ],
                    if (driverUser != null) ...[
                      const SizedBox(height: 8),
                      _detailLine(
                        dt('سائق'),
                        '${driverUser['name'] ?? dt('سائق')} ${driverUser['phone'] != null ? '• ${driverUser['phone']}' : ''}'
                            .trim(),
                      ),
                    ],
                  ],
                ),
              ),
              if (notes.isNotEmpty) ...[
                const SizedBox(height: 12),
                Text(
                  '${dt('ملاحظات')}: $notes',
                  style: TextStyle(color: DarbColors.muted, fontSize: 12.5),
                ),
              ],
              const SizedBox(height: 14),
              DarbSurfaceCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  children: [
                    if (row['subtotal'] != null && !peer)
                      Row(
                        children: [
                          Expanded(child: Text(dt('المجموع الفرعي'))),
                          Text('${row['subtotal']} $currency'),
                        ],
                      ),
                    if (row['deliveryFee'] != null) ...[
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Expanded(child: Text(dt('رسوم التوصيل'))),
                          Text('${row['deliveryFee']} $currency'),
                        ],
                      ),
                    ],
                    const Divider(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            dt('الإجمالي'),
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        Text(
                          '${row['total'] ?? ''} $currency',
                          style: TextStyle(
                            color: DarbColors.brandForeground,
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailLine(String label, String value) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '$label: ',
            style: TextStyle(
              color: DarbColors.muted,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: DarbColors.ink,
                fontSize: 12.5,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      );

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () => _load(targetPage: page),
      color: DarbColors.brandForeground,
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: DarbColors.heroGradient,
              borderRadius: BorderRadius.circular(DarbRadius.xl),
              boxShadow: DarbElevation.cardFor(Theme.of(context).brightness),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        dt('إدارة الطلبات'),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        loading
                            ? dt('جارٍ تحديث البيانات')
                            : '${dt('إجمالي الطلبات')}: $total',
                        style: TextStyle(
                          color: Colors.white.withValues(alpha: .78),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: .14),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.receipt_long_rounded,
                        color: DarbColors.lime,
                        size: 20,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '$total',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final type in _types) ...[
                  ChoiceChip(
                    label: Text(_typeLabel(type)),
                    selected: selectedType == type,
                    onSelected: loading
                        ? null
                        : (_) {
                            selectedType = type;
                            _load(targetPage: 1);
                          },
                  ),
                  const SizedBox(width: 8),
                ],
              ],
            ),
          ),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final st in _statuses) ...[
                  FilterChip(
                    label: Text(_statusLabel(st, peer: false)),
                    selected: selectedStatus == st,
                    onSelected: loading
                        ? null
                        : (_) {
                            selectedStatus = st;
                            _load(targetPage: 1);
                          },
                  ),
                  const SizedBox(width: 8),
                ],
              ],
            ),
          ),
          const SizedBox(height: 16),
          if (loading)
            ...List.generate(
              3,
              (_) => const Padding(
                padding: EdgeInsets.only(bottom: 10),
                child: DarbSkeletonCard(lines: 3),
              ),
            )
          else if (error != null)
            _ErrorPanel(message: error!, retry: () => _load(targetPage: page))
          else if (items.isEmpty)
            _EmptyPanel(text: dt('لا توجد طلبات مطابقة للتصفية'))
          else ...[
            for (var index = 0; index < items.length; index++)
              DarbFadeSlide(
                delay: DarbMotion.cappedStaggerDelay(index),
                child: _orderSummaryCard(items[index]),
              ),
            if (pages > 1) ...[
              const SizedBox(height: 8),
              DarbSurfaceCard(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                child: Row(
                  children: [
                    OutlinedButton.icon(
                      onPressed: page > 1 && !loading
                          ? () => _load(targetPage: page - 1)
                          : null,
                      icon: Icon(DarbIcons.arrowBack(context), size: 17),
                      label: Text(dt('السابق')),
                    ),
                    Expanded(
                      child: Text(
                        '$page / $pages',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: DarbColors.ink,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: page < pages && !loading
                          ? () => _load(targetPage: page + 1)
                          : null,
                      icon: Icon(DarbIcons.arrowForward(context), size: 17),
                      label: Text(dt('التالي')),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget _orderSummaryCard(dynamic row) {
    final status = row['status']?.toString() ?? '';
    final peer = row['type'] == 'PEER_DELIVERY';
    final orderNumber = row['orderNumber']?.toString() ?? row['id']?.toString() ?? '';
    final vendorName = _localizedAdminVendorName(row['vendor']);
    final cityName = _localizedAdminCityName(row['city']);
    final customerName = row['customer']?['name']?.toString().trim() ?? '';
    final customerPhone = row['customer']?['phone']?.toString().trim() ?? '';
    final driverName = row['driver']?['user']?['name']?.toString().trim() ?? '';
    final totalStr = '${row['total'] ?? ''} ${row['currency'] ?? ''}'.trim();

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DarbSurfaceCard(
        onTap: () => _showOrderDetails(row),
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: DarbColors.surfaceAlt,
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    peer
                        ? Icons.local_shipping_outlined
                        : Icons.storefront_rounded,
                    color: DarbColors.brandForeground,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${peer ? dt('طلب توصيل مستقل') : (vendorName.isEmpty ? dt('طلب') : vendorName)} • $orderNumber',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: DarbColors.ink,
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        [
                          if (cityName.isNotEmpty) cityName,
                          if (customerName.isNotEmpty) customerName,
                          if (customerName.isEmpty && customerPhone.isNotEmpty)
                            customerPhone,
                        ].join(' • '),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: DarbColors.muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                DarbStatusBadge(
                  label: _statusLabel(status, peer: peer),
                  tone: _statusTone(status),
                  pulse: status == 'ASSIGNED' || status == 'PICKED_UP',
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    driverName.isNotEmpty
                        ? '${dt('سائق')}: $driverName'
                        : '${dt('الإجمالي')}: $totalStr',
                    style: TextStyle(
                      color: driverName.isNotEmpty
                          ? DarbColors.muted
                          : DarbColors.brandForeground,
                      fontWeight: FontWeight.w800,
                      fontSize: 12.5,
                    ),
                  ),
                ),
                if (driverName.isNotEmpty)
                  Text(
                    totalStr,
                    style: TextStyle(
                      color: DarbColors.brandForeground,
                      fontWeight: FontWeight.w900,
                      fontSize: 13.5,
                    ),
                  ),
                const SizedBox(width: 6),
                Icon(
                  DarbIcons.chevronForward(context),
                  size: 19,
                  color: DarbColors.muted,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AdminQueue extends StatefulWidget {
  final String kind;
  const AdminQueue({super.key, required this.kind});

  @override
  State<AdminQueue> createState() => _AdminQueueState();
}

class _AdminQueueState extends State<AdminQueue> {
  bool loading = true;
  bool working = false;
  String? error;
  List rows = [];

  String get endpoint => widget.kind == 'vendors'
      ? '/admin/vendors/pending'
      : '/admin/drivers/pending';

  String get heading => widget.kind == 'vendors'
      ? dt('طلبات انضمام المتاجر')
      : dt('طلبات انضمام السائقين');

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      rows = await Api.instance.get(endpoint) as List;
      error = null;
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _confirmAndSetStatus(String id, String status) async {
    if (status == 'REJECTED' || status == 'SUSPENDED') {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          icon: Icon(Icons.warning_amber_rounded, color: DarbColors.danger),
          title: Text(dt('تأكيد الإجراء')),
          content: Text(
            status == 'REJECTED'
                ? dt('هل أنت متأكد من رفض هذا الطلب؟')
                : dt('هل أنت متأكد من تعليق هذا الحساب؟'),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: DarbColors.danger,
                foregroundColor: Colors.white,
              ),
              onPressed: () => Navigator.pop(ctx, true),
              child: Text(
                status == 'REJECTED' ? dt('رفض') : dt('تعليق'),
              ),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
    }
    await _setStatus(id, status);
  }

  Future<void> _setStatus(String id, String status) async {
    setState(() => working = true);
    try {
      await Api.instance.patch('/admin/${widget.kind}/$id/status', {
        'status': status,
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(dt('تم تحديث الحالة بنجاح'))),
        );
      }
      await _load();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  @override
  Widget build(BuildContext context) => RefreshIndicator(
        onRefresh: _load,
        color: DarbColors.brandForeground,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: DarbColors.heroGradient,
                borderRadius: BorderRadius.circular(DarbRadius.xl),
                boxShadow: DarbElevation.cardFor(Theme.of(context).brightness),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          heading,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          loading
                              ? dt('جارٍ تحديث البيانات')
                              : dt('اسحب للأسفل لتحديث الطلبات'),
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: .78),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: .14),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          widget.kind == 'vendors'
                              ? Icons.storefront_rounded
                              : Icons.delivery_dining_rounded,
                          color: DarbColors.lime,
                          size: 20,
                        ),
                        if (!loading && error == null) ...[
                          const SizedBox(width: 6),
                          Text(
                            '${rows.length}',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (loading)
              ...List.generate(
                3,
                (_) => const Padding(
                  padding: EdgeInsets.only(bottom: 10),
                  child: DarbSkeletonCard(lines: 3),
                ),
              ),
            if (error != null) _ErrorPanel(message: error!, retry: _load),
            if (!loading && error == null && rows.isEmpty)
              _EmptyPanel(text: dt('لا توجد طلبات معلّقة حالياً')),
            if (!loading && error == null)
              for (var index = 0; index < rows.length; index++)
                DarbFadeSlide(
                  delay: DarbMotion.cappedStaggerDelay(index),
                  child: _requestCard(rows[index]),
                ),
          ],
        ),
      );

  Widget _requestCard(dynamic row) {
    final user = row['user'] as Map? ?? const {};
    final translations = row['translations'] as List? ?? const [];
    final title = widget.kind == 'vendors'
        ? (translations.isEmpty
            ? dt('متجر جديد')
            : translations.first['name']?.toString() ?? dt('متجر جديد'))
        : (user['name']?.toString().trim().isNotEmpty ?? false)
            ? user['name'].toString()
            : dt('سائق جديد');
    final phone = user['phone']?.toString().trim() ?? '';
    final email = user['email']?.toString().trim() ?? '';
    final contact = phone.isNotEmpty
        ? phone
        : email.isNotEmpty
            ? email
            : dt('غير محدد');
    String city = '';
    if (widget.kind == 'drivers') {
      city = _localizedAdminCityName(row['city']);
    } else if (row['cities'] is List && (row['cities'] as List).isNotEmpty) {
      final firstCity = (row['cities'] as List).first;
      if (firstCity is Map) {
        city = _localizedAdminCityName(firstCity['city']);
      }
    }
    final detail = widget.kind == 'vendors'
        ? row['type']?.toString().trim() ?? ''
        : row['vehicleType']?.toString().trim() ?? '';
    final id = row['id'].toString();

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: DarbSurfaceCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: DarbColors.surfaceAlt,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Icon(
                    widget.kind == 'vendors'
                        ? Icons.storefront_rounded
                        : Icons.delivery_dining_rounded,
                    color: DarbColors.brandForeground,
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                          color: DarbColors.ink,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        contact,
                        style: TextStyle(color: DarbColors.muted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                DarbStatusBadge(
                  label: dt('قيد المراجعة'),
                  tone: DarbTone.warning,
                ),
              ],
            ),
            if (detail.isNotEmpty || city.isNotEmpty) ...[
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (detail.isNotEmpty)
                    DarbStatusBadge(
                      label: detail,
                      tone: DarbTone.brand,
                      icon: Icons.category_outlined,
                    ),
                  if (city.isNotEmpty)
                    DarbStatusBadge(
                      label: city,
                      tone: DarbTone.info,
                      icon: Icons.location_city_outlined,
                    ),
                ],
              ),
            ],
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: FilledButton(
                    onPressed: working ? null : () => _setStatus(id, 'APPROVED'),
                    child: Text(dt('اعتماد الطلب')),
                  ),
                ),
                const SizedBox(width: 9),
                OutlinedButton(
                  onPressed: working
                      ? null
                      : () => _confirmAndSetStatus(
                            id,
                            widget.kind == 'vendors' ? 'REJECTED' : 'SUSPENDED',
                          ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: DarbColors.danger,
                    side: BorderSide(color: DarbColors.danger),
                  ),
                  child: Text(
                    widget.kind == 'vendors' ? dt('رفض') : dt('تعليق'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class AdminDeliveryZones extends StatefulWidget {
  const AdminDeliveryZones({super.key});
  @override
  State<AdminDeliveryZones> createState() => _AdminDeliveryZonesState();
}

class _AdminDeliveryZonesState extends State<AdminDeliveryZones> {
  bool loading = true;
  bool working = false;
  String? error;
  List zones = [];
  List cities = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final values = await Future.wait([
        Api.instance.get('/admin/delivery-zones'),
        Api.instance.get('/cities'),
      ]);
      zones = values[0] as List;
      cities = values[1] as List;
      error = null;
    } catch (e) {
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _edit([Map? zone]) async {
    final selectableCities = zone == null
        ? cities
            .where((c) => !zones.any((z) => z['cityId'] == c['id']))
            .toList()
        : cities;
    if (selectableCities.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(dt('لا توجد مدن أخرى تحتاج إلى إعداد رسوم'))),
      );
      return;
    }
    final name = TextEditingController(text: zone?['name']?.toString() ?? '');
    final base = TextEditingController(text: zone?['feeBase']?.toString() ?? '');
    final perKm =
        TextEditingController(text: zone?['feePerKm']?.toString() ?? '');
    String cityId =
        zone?['cityId']?.toString() ?? selectableCities.first['id'].toString();
    String? dialogError;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDialog) => AlertDialog(
          title: Text(
            zone == null ? dt('إضافة منطقة توصيل') : dt('تعديل رسوم التوصيل'),
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (zone == null) ...[
                  DropdownButtonFormField<String>(
                    initialValue: cityId,
                    decoration: InputDecoration(labelText: dt('المدينة')),
                    items: [
                      for (final c in selectableCities)
                        DropdownMenuItem(
                          value: c['id'].toString(),
                          child: Text(_localizedAdminCityName(c)),
                        ),
                    ],
                    onChanged: (v) {
                      if (v != null) setDialog(() => cityId = v);
                    },
                  ),
                  const SizedBox(height: 10),
                ],
                TextField(
                  controller: name,
                  decoration: InputDecoration(labelText: dt('وصف إعداد الرسوم')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: base,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration:
                      InputDecoration(labelText: dt('الرسم الأساسي (ل.س)')),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: perKm,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration:
                      InputDecoration(labelText: dt('الرسم لكل كيلومتر (ل.س)')),
                ),
                if (dialogError != null) ...[
                  const SizedBox(height: 10),
                  Text(
                    dialogError!,
                    style: TextStyle(color: DarbColors.danger, fontSize: 12),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text(dt('إلغاء')),
            ),
            FilledButton(
              onPressed: () {
                final feeBase = double.tryParse(base.text.trim());
                final feePerKm = double.tryParse(perKm.text.trim());
                if (name.text.trim().isEmpty ||
                    feeBase == null ||
                    feePerKm == null ||
                    feeBase < 0 ||
                    feePerKm < 0) {
                  setDialog(
                    () => dialogError = dt('أدخل اسمًا ورسومًا رقمية غير سالبة'),
                  );
                  return;
                }
                Navigator.pop(ctx, true);
              },
              child: Text(dt('حفظ')),
            ),
          ],
        ),
      ),
    );

    if (ok == true) {
      final feeBase = double.parse(base.text.trim());
      final feePerKm = double.parse(perKm.text.trim());
      setState(() => working = true);
      try {
        final body = <String, dynamic>{
          'name': name.text.trim(),
          'feeBase': feeBase,
          'feePerKm': feePerKm,
          if (zone == null) 'cityId': cityId,
        };
        if (zone == null) {
          await Api.instance.post('/admin/delivery-zones', body);
        } else {
          await Api.instance.patch('/admin/delivery-zones/${zone['id']}', body);
        }
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(dt('تم حفظ إعدادات التوصيل'))),
          );
        }
        await _load();
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(e.toString())),
          );
        }
      } finally {
        if (mounted) setState(() => working = false);
      }
    }
    name.dispose();
    base.dispose();
    perKm.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(
          onPressed: working ? null : () => _edit(),
          icon: const Icon(Icons.add_rounded),
          label: Text(dt('إضافة رسوم لمدينة')),
        ),
        body: loading
            ? ListView(
                padding: const EdgeInsets.all(18),
                children: const [
                  DarbSkeletonCard(lines: 2),
                  SizedBox(height: 12),
                  DarbSkeletonCard(lines: 2),
                ],
              )
            : error != null
                ? ListView(
                    padding: const EdgeInsets.all(18),
                    children: [_ErrorPanel(message: error!, retry: _load)],
                  )
                : RefreshIndicator(
                    onRefresh: _load,
                    color: DarbColors.brandForeground,
                    child: ListView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(18, 16, 18, 92),
                      children: [
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            gradient: DarbColors.heroGradient,
                            borderRadius: BorderRadius.circular(DarbRadius.xl),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                dt('إعداد رسوم التوصيل'),
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                dt('يُضبط رسم واحد لكل مدينة. احتساب رسم الكيلومتر يتطلب تحديد موقع المتجر وموقع عنوان العميل.'),
                                style: TextStyle(
                                  color: Colors.white.withValues(alpha: .78),
                                  fontSize: 12,
                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (zones.isEmpty)
                          _EmptyPanel(text: dt('لم تُضف رسوم توصيل بعد'))
                        else
                          for (var i = 0; i < zones.length; i++)
                            DarbFadeSlide(
                              delay: DarbMotion.cappedStaggerDelay(i),
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: DarbSurfaceCard(
                                  padding: const EdgeInsets.all(14),
                                  child: Row(
                                    children: [
                                      Container(
                                        width: 44,
                                        height: 44,
                                        decoration: BoxDecoration(
                                          color: DarbColors.surfaceAlt,
                                          borderRadius:
                                              BorderRadius.circular(14),
                                        ),
                                        child: Icon(
                                          Icons.payments_outlined,
                                          color: DarbColors.brandForeground,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              zones[i]['name']?.toString() ??
                                                  dt('منطقة'),
                                              style: TextStyle(
                                                color: DarbColors.ink,
                                                fontWeight: FontWeight.w900,
                                                fontSize: 14.5,
                                              ),
                                            ),
                                            if (_localizedAdminCityName(
                                                    zones[i]['city'])
                                                .isNotEmpty) ...[
                                              const SizedBox(height: 2),
                                              Text(
                                                _localizedAdminCityName(
                                                    zones[i]['city']),
                                                style: TextStyle(
                                                  color: DarbColors
                                                      .brandForeground,
                                                  fontSize: 11.5,
                                                  fontWeight: FontWeight.w700,
                                                ),
                                              ),
                                            ],
                                            const SizedBox(height: 4),
                                            Text(
                                              dt('رسوم المنطقة: ${zones[i]['feeBase']} ل.س • لكل كم: ${zones[i]['feePerKm']} ل.س'),
                                              style: TextStyle(
                                                color: DarbColors.muted,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      IconButton(
                                        onPressed: working
                                            ? null
                                            : () => _edit(zones[i] as Map),
                                        icon: const Icon(Icons.edit_outlined),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                      ],
                    ),
                  ),
      );
}
