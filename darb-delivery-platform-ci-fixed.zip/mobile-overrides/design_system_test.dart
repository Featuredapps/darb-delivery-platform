import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:darb/design_system.dart';
import 'package:darb/localizations.dart';
import 'package:darb/screens/app_shell.dart';
import 'package:darb/screens/city_carousel.dart';
import 'package:darb/screens/login_screen.dart';

void main() {
  tearDown(() {
    DarbTheme.updateBrightness(Brightness.light);
    DarbTheme.mode.value = ThemeMode.system;
    darbLocale.value = const Locale('ar');
  });

  Widget wrapScreen(
    Widget child, {
    Locale? locale,
    bool disableAnimations = true,
  }) =>
      ValueListenableBuilder<Locale>(
        valueListenable: darbLocale,
        builder: (context, activeLocale, _) => MediaQuery(
          data: MediaQueryData(disableAnimations: disableAnimations),
          child: MaterialApp(
            locale: locale ?? activeLocale,
            supportedLocales: AppLocalizations.supportedLocales,
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            theme: DarbTheme.light,
            darkTheme: DarbTheme.dark,
            home: child,
          ),
        ),
      );

  group('DARB design system', () {
    test('defines the approved Material 3 theme', () {
      final theme = DarbTheme.light;
      expect(theme.useMaterial3, isTrue);
      expect(theme.colorScheme.primary, DarbColors.forest);
      expect(theme.scaffoldBackgroundColor, DarbColors.canvas);
      expect(theme.cardTheme.color, const Color(0xFFFFFFFF));
      expect(theme.filledButtonTheme.style, isNotNull);
    });

    test('defines a complete dark Material 3 theme with semantic contrast', () {
      final theme = DarbTheme.dark;
      expect(theme.useMaterial3, isTrue);
      expect(theme.brightness, Brightness.dark);
      expect(theme.colorScheme.primary, const Color(0xFFB9E4D2));
      expect(theme.scaffoldBackgroundColor, const Color(0xFF0B1512));
      expect(theme.cardTheme.color, const Color(0xFF13221D));
      expect(theme.textTheme.headlineLarge?.color, const Color(0xFFF1F5F1));
      expect(theme.filledButtonTheme.style, isNotNull);
      expect(theme.outlinedButtonTheme.style, isNotNull);
      expect(theme.snackBarTheme.backgroundColor, const Color(0xFF1C342C));
    });

    test('uses the same DARB route transition in light and dark themes', () {
      for (final theme in [DarbTheme.light, DarbTheme.dark]) {
        for (final platform in TargetPlatform.values) {
          expect(
            theme.pageTransitionsTheme.builders[platform],
            isA<DarbPageTransitionsBuilder>(),
          );
        }
      }
    });

    test('defaults theme selection to follow the device', () {
      expect(DarbTheme.mode.value, ThemeMode.system);
    });

    test('semantic palette adapts when active brightness changes', () {
      DarbTheme.updateBrightness(Brightness.light);
      final lightCanvas = DarbColors.canvas;
      final lightSurface = DarbColors.surface;
      final lightInk = DarbColors.ink;
      final lightShimmer = DarbColors.shimmerBase;

      DarbTheme.updateBrightness(Brightness.dark);
      expect(DarbColors.canvas, isNot(lightCanvas));
      expect(DarbColors.surface, isNot(lightSurface));
      expect(DarbColors.ink, isNot(lightInk));
      expect(DarbColors.shimmerBase, isNot(lightShimmer));
      expect(DarbColors.ink, const Color(0xFFF1F5F1));
      expect(DarbColors.line, const Color(0xFF2A3B33));

      DarbTheme.updateBrightness(Brightness.light);
      expect(DarbColors.canvas, lightCanvas);
      expect(DarbColors.surface, lightSurface);
      expect(DarbColors.ink, lightInk);
    });

    test('provides consistent spacing, radius and motion tokens', () {
      expect(DarbSpace.xs, 8);
      expect(DarbSpace.md, 16);
      expect(DarbRadius.md, 16);
      expect(DarbRadius.hero, 36);
      expect(DarbMotion.fast, const Duration(milliseconds: 160));
      expect(DarbMotion.standard, const Duration(milliseconds: 260));
    });

    test('provides rich motion timings and capped stagger delays', () {
      expect(DarbMotion.press.inMilliseconds, 120);
      expect(DarbMotion.route.inMilliseconds, 340);
      expect(DarbMotion.staggerDelay(3).inMilliseconds, 165);
      expect(DarbMotion.cappedStaggerDelay(0), Duration.zero);
      expect(DarbMotion.cappedStaggerDelay(20).inMilliseconds, 440);
    });

    test('includes semantic status colors', () {
      expect(DarbColors.success, isA<Color>());
      expect(DarbColors.warning, isA<Color>());
      expect(DarbColors.info, isA<Color>());
      expect(DarbColors.borderStrong, isA<Color>());
      expect(DarbColors.scrim, isA<Color>());
    });

    testWidgets(
      'DarbFadeSlide skips entrance motion when reduced motion is on',
      (tester) async {
        await tester.pumpWidget(
          const MaterialApp(
            home: MediaQuery(
              data: MediaQueryData(disableAnimations: true),
              child: Scaffold(
                body: DarbFadeSlide(child: Text('DARB motion')),
              ),
            ),
          ),
        );

        final fadeFinder = find.descendant(
          of: find.byType(DarbFadeSlide),
          matching: find.byType(FadeTransition),
        );
        expect(fadeFinder, findsOneWidget);

        final fade = tester.widget<FadeTransition>(fadeFinder);
        expect(fade.opacity.value, 1);
      },
    );

    testWidgets(
      'DarbPressScale renders static scale when reduced motion is on and triggers onTap',
      (tester) async {
        var tapped = false;
        await tester.pumpWidget(
          MaterialApp(
            home: MediaQuery(
              data: const MediaQueryData(disableAnimations: true),
              child: Scaffold(
                body: DarbPressScale(
                  onTap: () => tapped = true,
                  child: const SizedBox(width: 100, height: 48, child: Text('Go')),
                ),
              ),
            ),
          ),
        );

        final scaledFinder = find.descendant(
          of: find.byType(DarbPressScale),
          matching: find.byType(AnimatedScale),
        );
        expect(tester.widget<AnimatedScale>(scaledFinder).duration, Duration.zero);

        await tester.tap(find.text('Go'));
        await tester.pump();
        expect(tapped, isTrue);
      },
    );

    testWidgets(
      'Pulse 2026 primitives render cleanly and respect reduced motion',
      (tester) async {
        await tester.pumpWidget(
          const MaterialApp(
            home: MediaQuery(
              data: MediaQueryData(disableAnimations: true),
              child: Scaffold(
                body: Column(
                  children: [
                    DarbSectionHeader(
                      title: 'Stores',
                      subtitle: 'Browse nearby',
                    ),
                    DarbStatusBadge(
                      label: 'Live',
                      tone: DarbTone.success,
                      pulse: true,
                    ),
                    DarbSkeletonCard(),
                    DarbStepProgress(totalSteps: 3, currentStep: 1),
                    DarbSurfaceCard(child: Text('Card body')),
                  ],
                ),
              ),
            ),
          ),
        );

        expect(find.text('Stores'), findsOneWidget);
        expect(find.text('Live'), findsOneWidget);
        expect(find.text('Card body'), findsOneWidget);
        expect(find.byType(DarbPulseDot), findsOneWidget);
        expect(find.byType(DarbSkeleton), findsWidgets);
        expect(find.byType(DarbStepProgress), findsOneWidget);
      },
    );

    testWidgets('DarbIcons adapt forward/back arrows to RTL and LTR', (
      tester,
    ) async {
      late IconData rtlChevron;
      late IconData ltrChevron;

      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: TextDirection.rtl,
            child: Builder(
              builder: (context) {
                rtlChevron = DarbIcons.chevronForward(context);
                return const SizedBox.shrink();
              },
            ),
          ),
        ),
      );

      await tester.pumpWidget(
        MaterialApp(
          home: Directionality(
            textDirection: TextDirection.ltr,
            child: Builder(
              builder: (context) {
                ltrChevron = DarbIcons.chevronForward(context);
                return const SizedBox.shrink();
              },
            ),
          ),
        ),
      );

      expect(rtlChevron, Icons.chevron_left_rounded);
      expect(ltrChevron, Icons.chevron_right_rounded);
    });
  });

  group('DARB localizations & RTL/LTR', () {
    test('tracks textDirection accurately for ar, en, and tr', () {
      const ar = AppLocalizations(Locale('ar'));
      const en = AppLocalizations(Locale('en'));
      const tr = AppLocalizations(Locale('tr'));

      expect(ar.isRtl, isTrue);
      expect(ar.textDirection, TextDirection.rtl);
      expect(en.isRtl, isFalse);
      expect(en.textDirection, TextDirection.ltr);
      expect(tr.isRtl, isFalse);
      expect(tr.textDirection, TextDirection.ltr);
    });

    test('translates static and dynamic strings across ar, en, and tr', () {
      darbLocale.value = const Locale('en');
      expect(dt('مساعد دَرْب الذكي'), 'DARB Smart Assistant');
      expect(dt('التبديل إلى الوضع الليلي'), 'Switch to dark mode');
      expect(dt('متابعة إلى تأكيد الطلب • 3'), 'Continue to checkout • 3');
      expect(
        dt('رسوم المنطقة: 1000 ل.س • لكل كم: 500 ل.س'),
        'Zone fees: 1000 SYP • per km: 500 SYP',
      );
      expect(dt('الخطوة 2 من 3'), 'Step 2 of 3');

      darbLocale.value = const Locale('tr');
      expect(dt('مساعد دَرْب الذكي'), 'DARB Akıllı Asistan');
      expect(dt('التبديل إلى الوضع الليلي'), 'Koyu temaya geç');
      expect(dt('متابعة إلى تأكيد الطلب • 3'), 'Sipariş onayına geç • 3');
      expect(
        dt('رسوم المنطقة: 1000 ل.س • لكل كم: 500 ل.س'),
        'Bölge ücretleri: 1000 SYP • km başına: 500 SYP',
      );
      expect(dt('الخطوة 2 من 3'), 'Adım 2 / 3');

      darbLocale.value = const Locale('ar');
      expect(dt('مساعد دَرْب الذكي'), 'مساعد دَرْب الذكي');
    });
  });

  group('DarbCityCarousel & LoginScreen vertical slice', () {
    test('SyrianPhoneFormatter formats and caps 10 Syrian digits', () {
      final formatter = SyrianPhoneFormatter();
      final result = formatter.formatEditUpdate(
        TextEditingValue.empty,
        const TextEditingValue(text: '0933123456789'),
      );
      expect(result.text, '093 312 3456');
    });

    testWidgets(
      'DarbCityCarousel renders city badge in active locale, swipes, and jumps on dot tap',
      (tester) async {
        await tester.pumpWidget(
          wrapScreen(const Scaffold(body: SizedBox(height: 280, child: DarbCityCarousel()))),
        );
        expect(find.text('حلب'), findsOneWidget);

        await tester.fling(find.byType(PageView), const Offset(450, 0), 1000);
        await tester.pumpAndSettle();
        expect(find.text('حمص'), findsOneWidget);

        await tester.tap(find.byKey(const ValueKey('city_dot_damascus')));
        await tester.pumpAndSettle();
        expect(find.text('دمشق'), findsOneWidget);
      },
    );

    testWidgets(
      'LoginScreen validates Syrian phone, toggles theme/language, and shows googleUnavailable state',
      (tester) async {
        await tester.pumpWidget(wrapScreen(const LoginScreen()));

        final primaryButton = find.byKey(const ValueKey('login_primary_cta'));
        expect(tester.widget<FilledButton>(primaryButton).onPressed, isNull);

        await tester.enterText(
          find.byKey(const ValueKey('login_phone_field')),
          '0933123456',
        );
        await tester.pump();
        expect(find.text('093 312 3456'), findsOneWidget);
        expect(tester.widget<FilledButton>(primaryButton).onPressed, isNotNull);

        await tester.tap(find.byKey(const ValueKey('login_google_cta')));
        await tester.pumpAndSettle();
        expect(
          find.text('تسجيل Google غير مفعّل على الخادم حاليًا. استخدم رقم الهاتف.'),
          findsOneWidget,
        );

        await tester.tap(find.byIcon(Icons.light_mode_rounded));
        await tester.pump();
        expect(DarbTheme.mode.value, ThemeMode.dark);

        await tester.tap(find.text('EN'));
        await tester.pump();
        expect(darbLocale.value, const Locale('en'));
      },
    );

    test('extractValidAuthTokens validates auth token payload strictly', () {
      expect(extractValidAuthTokens(null), isNull);
      expect(extractValidAuthTokens('invalid'), isNull);
      expect(extractValidAuthTokens(<String, dynamic>{}), isNull);
      expect(extractValidAuthTokens({'tokens': null}), isNull);
      expect(extractValidAuthTokens({'tokens': 'bad'}), isNull);
      expect(
        extractValidAuthTokens({'tokens': {'accessToken': 'abc'}}),
        isNull,
      );
      expect(
        extractValidAuthTokens({
          'tokens': {'accessToken': '   ', 'refreshToken': 'ref'},
        }),
        isNull,
      );
      expect(
        extractValidAuthTokens({
          'tokens': {'accessToken': 123, 'refreshToken': 'ref'},
        }),
        isNull,
      );

      final valid = extractValidAuthTokens({
        'tokens': {'accessToken': 'acc-1', 'refreshToken': 'ref-1'},
      });
      expect(valid, isNotNull);
      expect(valid!['accessToken'], 'acc-1');
      expect(valid['refreshToken'], 'ref-1');
    });

    testWidgets(
      'LoginScreen preserves entered state when switching language live',
      (tester) async {
        await tester.pumpWidget(
          wrapScreen(const LoginScreen(key: ValueKey('login'))),
        );

        await tester.enterText(
          find.byKey(const ValueKey('login_phone_field')),
          '0933123456',
        );
        await tester.pump();
        expect(find.text('093 312 3456'), findsOneWidget);

        await tester.tap(find.text('EN'));
        await tester.pump();
        expect(darbLocale.value, const Locale('en'));
        expect(find.text('Sign in with your phone'), findsOneWidget);
        expect(find.text('093 312 3456'), findsOneWidget);
      },
    );
  });

  group('DARB Pulse 2026 app flows & screens', () {
    testWidgets(
      'DarbSurfaceCard triggers onTap cleanly without gesture conflicts',
      (tester) async {
        var tappedCount = 0;
        await tester.pumpWidget(
          wrapScreen(
            Scaffold(
              body: Center(
                child: DarbSurfaceCard(
                  onTap: () => tappedCount++,
                  child: const Text('Tap target'),
                ),
              ),
            ),
          ),
        );

        await tester.tap(find.text('Tap target'));
        await tester.pump();
        expect(tappedCount, 1);
      },
    );

    testWidgets(
      'AccountPage switches theme mode, opens support assistant, and confirms logout',
      (tester) async {
        var assistantOpened = false;
        var loggedOut = false;

        await tester.pumpWidget(
          wrapScreen(
            Scaffold(
              body: AccountPage(
                me: const {
                  'name': 'أحمد',
                  'phone': '0933123456',
                  'email': 'ahmad@darb.sy',
                  'role': 'CUSTOMER',
                  'locale': 'ar',
                },
                onLogout: () => loggedOut = true,
                onOpenAssistant: () => assistantOpened = true,
              ),
            ),
          ),
        );

        expect(find.text('أحمد'), findsNWidgets(2));
        expect(find.text('حساب عميل'), findsOneWidget);
        expect(find.text('كن سائقاً في دَرْب'), findsOneWidget);
        expect(find.text('انضم بمتجرك'), findsOneWidget);

        await tester.scrollUntilVisible(
          find.text('مظهر التطبيق'),
          240,
          scrollable: find.byType(Scrollable).first,
        );
        await tester.tap(find.text('مظهر التطبيق'));
        await tester.pumpAndSettle();

        expect(find.text('ليلي'), findsOneWidget);
        await tester.tap(find.text('ليلي'));
        await tester.pumpAndSettle();
        expect(DarbTheme.mode.value, ThemeMode.dark);

        await tester.scrollUntilVisible(
          find.text('المساعدة والدعم'),
          240,
          scrollable: find.byType(Scrollable).first,
        );
        await tester.tap(find.text('المساعدة والدعم'));
        await tester.pumpAndSettle();
        expect(find.text('مركز المساعدة دَرْب'), findsOneWidget);

        await tester.tap(find.text('اسأل مساعد دَرْب'));
        await tester.pumpAndSettle();
        expect(assistantOpened, isTrue);

        await tester.scrollUntilVisible(
          find.text('تسجيل الخروج'),
          240,
          scrollable: find.byType(Scrollable).first,
        );
        await tester.tap(find.text('تسجيل الخروج'));
        await tester.pumpAndSettle();
        expect(find.text('تسجيل الخروج؟'), findsOneWidget);

        await tester.tap(find.widgetWithText(FilledButton, 'تسجيل الخروج'));
        await tester.pumpAndSettle();
        expect(loggedOut, isTrue);
      },
    );

    testWidgets(
      'OrderCreatedScreen renders order summary in Arabic RTL and English LTR',
      (tester) async {
        const order = <String, dynamic>{
          'orderNumber': 'DRB-2026-009',
          'deliveryFee': '25',
          'total': '175',
          'currency': 'ل.س',
        };

        await tester.pumpWidget(
          wrapScreen(
            const OrderCreatedScreen(order: order),
            locale: const Locale('ar'),
          ),
        );
        expect(find.text('DRB-2026-009'), findsOneWidget);
        expect(find.text('تم إرسال طلبك بنجاح'), findsOneWidget);
        expect(find.text('25 ل.س'), findsOneWidget);
        expect(find.text('175 ل.س'), findsOneWidget);

        darbLocale.value = const Locale('en');
        await tester.pumpWidget(
          wrapScreen(
            const OrderCreatedScreen(order: order),
            locale: const Locale('en'),
          ),
        );
        expect(find.text('Your order was submitted successfully'), findsOneWidget);
        expect(find.text('Cash on delivery'), findsOneWidget);
      },
    );

    test('translates Admin, Account, Tracking, and Theme keys across en and tr', () {
      darbLocale.value = const Locale('en');
      expect(dt('إدارة الطلبات'), 'Orders management');
      expect(dt('تأكيد الإجراء'), 'Confirm action');
      expect(dt('تم حفظ إعدادات التوصيل'), 'Delivery zone settings saved');
      expect(dt('مظهر التطبيق'), 'Appearance');
      expect(dt('العناوين المحفوظة'), 'Saved addresses');
      expect(dt('تفاصيل الطلب'), 'Order details');
      expect(dt('مسار حالة الطلب'), 'Order timeline');
      expect(dt('موقع السائق المباشر'), 'Live driver location');
      expect(dt('مساعد دَرْب التشغيلي'), 'DARB Operations Assistant');

      darbLocale.value = const Locale('tr');
      expect(dt('إدارة الطلبات'), 'Sipariş yönetimi');
      expect(dt('تأكيد الإجراء'), 'İşlemi onayla');
      expect(dt('تم حفظ إعدادات التوصيل'), 'Teslimat bölgesi ayarları kaydedildi');
      expect(dt('مظهر التطبيق'), 'Görünüm');
      expect(dt('العناوين المحفوظة'), 'Kayıtlı adresler');
      expect(dt('تفاصيل الطلب'), 'Sipariş ayrıntıları');
      expect(dt('مسار حالة الطلب'), 'Sipariş zaman çizelgesi');
      expect(dt('موقع السائق المباشر'), 'Canlı kurye konumu');
      expect(dt('مساعد دَرْب التشغيلي'), 'DARB Operasyon Asistanı');
    });
  });
}
