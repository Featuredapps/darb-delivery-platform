import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/api.dart';
import '../design_system.dart';
import '../main.dart';
import '../localizations.dart';
import '../notifications.dart';
import 'login_screen.dart';
import '../app_update.dart';

part 'admin_screens.dart';
part 'customer_screens.dart';
part 'peer_delivery_screen.dart';
part 'vendor_screens.dart';
part 'driver_screens.dart';
part 'account_screens.dart';
part 'account_pages.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int tab = 0;
  bool loading = true;
  String role = 'CUSTOMER';
  String? error;
  Map<String, dynamic>? me;

  @override
  void initState() {
    super.initState();
    _load();
    DarbNotifications.register();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    try {
      final data = await Api.instance.get('/auth/me');
      if (data is! Map) {
        throw const ApiException('استجابة الحساب غير مكتملة');
      }
      me = Map<String, dynamic>.from(data);
      role = me?['role']?.toString() ?? 'CUSTOMER';
      if (role == 'DRIVER') {
        DriverLocationReporter.start();
      } else {
        DriverLocationReporter.stop();
      }
      final savedLocale = me?['locale']?.toString();
      if (savedLocale == 'ar' || savedLocale == 'en' || savedLocale == 'tr') {
        darbLocale.value = Locale(savedLocale!);
      }
      error = null;
    } catch (e) {
      if (Api.instance.sessionInvalidated) {
        await _logout();
        return;
      }
      error = e.toString();
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _logout() async {
    DriverLocationReporter.stop();
    await DarbNotifications.unregister();
    await Api.instance.clear();
    if (mounted) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const LoginScreen(key: ValueKey('login'))),
        (_) => false,
      );
    }
  }

  void _openRoleAssistant() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _RoleAssistantSheet(role: role),
    );
  }

  @override
  void dispose() {
    DriverLocationReporter.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final reduceMotion = DarbMotion.reduceMotion(context);
    if (loading) {
      return Scaffold(
        backgroundColor: DarbColors.canvas,
        appBar: AppBar(
          backgroundColor: DarbColors.forest,
          foregroundColor: Colors.white,
          title: Text(dt('دَرْب')),
        ),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const DarbSkeleton(height: 120, radius: DarbRadius.xl),
            const SizedBox(height: 16),
            Text(
              dt('جارٍ تجهيز مساحة العمل...'),
              textAlign: TextAlign.start,
              style: TextStyle(color: DarbColors.muted, fontSize: 12),
            ),
            const SizedBox(height: 12),
            const DarbSkeletonCard(lines: 3),
            const SizedBox(height: 12),
            const DarbSkeletonCard(lines: 2),
          ],
        ),
      );
    }

    if (error != null) {
      return Scaffold(
        backgroundColor: DarbColors.canvas,
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: DarbSurfaceCard(
                  padding: const EdgeInsets.all(22),
                  borderRadius: DarbRadius.xl,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: DarbColors.warning.withValues(alpha: .12),
                          borderRadius: BorderRadius.circular(18),
                        ),
                        child: Icon(
                          Icons.cloud_off_rounded,
                          size: 28,
                          color: DarbColors.warning,
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        dt('تعذر تحميل حسابك'),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: DarbColors.ink,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        error!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: DarbColors.muted,
                          fontSize: 12.5,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: loading ? null : _load,
                          icon: const Icon(Icons.refresh_rounded, size: 18),
                          label: Text(dt('إعادة المحاولة')),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        dt('حسابك محفوظ. لن يتم تسجيل خروجك بسبب تعذر الاتصال.'),
                        textAlign: TextAlign.center,
                        style: TextStyle(color: DarbColors.muted, fontSize: 11.5),
                      ),
                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: _logout,
                        style: TextButton.styleFrom(
                          foregroundColor: DarbColors.danger,
                        ),
                        child: Text(dt('تسجيل الخروج')),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    final isAdmin = role == 'ADMIN';
    final isCustomer = role == 'CUSTOMER';
    final isVendor = role == 'VENDOR';
    final titles = isAdmin
        ? [
            dt('الطلبات'),
            dt('متاجر'),
            dt('السائقون'),
            dt('التوصيل'),
            dt('حسابي'),
          ]
        : isCustomer
            ? [dt('الرئيسية'), dt('طلباتي'), dt('حسابي')]
            : isVendor
                ? [dt('طلبات المتجر'), dt('المنتجات'), dt('حسابي')]
                : [dt('الطلبات المتاحة'), dt('توصيلاتي'), dt('حسابي')];
    final pages = isAdmin
        ? [
            const AdminOrders(),
            const AdminQueue(kind: 'vendors'),
            const AdminQueue(kind: 'drivers'),
            const AdminDeliveryZones(),
            AccountPage(
              me: me,
              onLogout: _logout,
              onRefreshAccount: _load,
              onOpenAssistant: _openRoleAssistant,
            ),
          ]
        : isCustomer
            ? [
                CustomerHome(
                  onOpenOrders: () {
                    if (mounted) setState(() => tab = 1);
                  },
                ),
                const CustomerOrders(),
                AccountPage(
                  me: me,
                  onLogout: _logout,
                  onRefreshAccount: _load,
                  onOpenAssistant: _openRoleAssistant,
                ),
              ]
            : isVendor
                ? [
                    const VendorOrders(),
                    const VendorProducts(),
                    AccountPage(
                      me: me,
                      onLogout: _logout,
                      onRefreshAccount: _load,
                      onOpenAssistant: _openRoleAssistant,
                    ),
                  ]
                : [
                    const DriverAvailable(),
                    const DriverOrders(),
                    AccountPage(
                      me: me,
                      onLogout: _logout,
                      onRefreshAccount: _load,
                      onOpenAssistant: _openRoleAssistant,
                    ),
                  ];
    final icons = isAdmin
        ? [
            Icons.receipt_long_rounded,
            Icons.storefront_outlined,
            Icons.delivery_dining_rounded,
            Icons.payments_outlined,
            Icons.person_outline_rounded,
          ]
        : isCustomer
            ? [
                Icons.explore_outlined,
                Icons.receipt_long_outlined,
                Icons.person_outline_rounded,
              ]
            : isVendor
                ? [
                    Icons.receipt_long_outlined,
                    Icons.inventory_2_outlined,
                    Icons.person_outline_rounded,
                  ]
                : [
                    Icons.radar_rounded,
                    Icons.route_outlined,
                    Icons.person_outline_rounded,
                  ];

    final activeTab = tab.clamp(0, pages.length - 1);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: DarbColors.forest,
        foregroundColor: Colors.white,
        surfaceTintColor: Colors.transparent,
        elevation: 0,
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [DarbColors.lime, DarbColors.mint],
                ),
                borderRadius: BorderRadius.circular(13),
              ),
              child: Text(
                dt('د'),
                style: TextStyle(
                  color: DarbColors.forest,
                  fontWeight: FontWeight.w900,
                  fontSize: 23,
                ),
              ),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    dt('دَرْب'),
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                      height: 1.1,
                    ),
                  ),
                  Text(
                    titles[activeTab],
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: .74),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: dt('مساعد دَرْب الذكي'),
            onPressed: _openRoleAssistant,
            icon: Icon(Icons.auto_awesome_rounded, color: DarbColors.lime, size: 22),
          ),
          IconButton(
            tooltip: Theme.of(context).brightness == Brightness.dark
                ? dt('التبديل إلى الوضع النهاري')
                : dt('التبديل إلى الوضع الليلي'),
            onPressed: () {
              final isDark = Theme.of(context).brightness == Brightness.dark;
              DarbTheme.setMode(isDark ? ThemeMode.light : ThemeMode.dark);
            },
            icon: AnimatedSwitcher(
              duration: DarbMotion.effectiveDuration(context, DarbMotion.expressive),
              switchInCurve: DarbMotion.expressiveCurve,
              switchOutCurve: DarbMotion.exit,
              transitionBuilder: (child, animation) => reduceMotion
                  ? child
                  : RotationTransition(
                      turns: Tween<double>(begin: .72, end: 1).animate(animation),
                      child: ScaleTransition(scale: animation, child: child),
                    ),
              child: Icon(
                Theme.of(context).brightness == Brightness.dark
                    ? Icons.dark_mode_rounded
                    : Icons.light_mode_rounded,
                key: ValueKey(Theme.of(context).brightness),
                color: DarbColors.lime,
                size: 23,
              ),
            ),
          ),
          ValueListenableBuilder<DarbUpdateInfo?>(
            valueListenable: DarbUpdater.instance.availableUpdate,
            builder: (context, update, _) => IconButton(
              tooltip: dt('تحديث التطبيق'),
              onPressed: () async {
                if (update == null) {
                  await DarbUpdater.instance.checkForUpdate(force: true);
                }
                final latest = DarbUpdater.instance.availableUpdate.value;
                if (!context.mounted) return;
                if (latest != null) {
                  showDialog<void>(
                    context: context,
                    builder: (_) => DarbUpdateDialog(info: latest),
                  );
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        DarbUpdater.instance.checkFailed
                            ? dt('تعذر التحقق من التحديث')
                            : dt('تطبيقك محدّث إلى آخر إصدار'),
                      ),
                    ),
                  );
                }
              },
              icon: Icon(
                update == null
                    ? Icons.system_update_alt_rounded
                    : Icons.system_update_rounded,
                color: update == null ? Colors.white : DarbColors.lime,
              ),
            ),
          ),
          IconButton(
            tooltip: dt('تحديث'),
            onPressed: _load,
            icon: const Icon(Icons.refresh_rounded, color: Colors.white),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: AnimatedSwitcher(
        duration: DarbMotion.effectiveDuration(context, DarbMotion.standard),
        switchInCurve: DarbMotion.enter,
        switchOutCurve: DarbMotion.exit,
        transitionBuilder: (child, animation) => reduceMotion
            ? child
            : FadeTransition(
                opacity: animation,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, .02),
                    end: Offset.zero,
                  ).animate(animation),
                  child: child,
                ),
              ),
        child: KeyedSubtree(
          key: ValueKey('tab_${role}_$activeTab'),
          child: pages[activeTab],
        ),
      ),
      bottomNavigationBar: DecoratedBox(
        decoration: BoxDecoration(
          border: Border(top: BorderSide(color: DarbColors.line)),
        ),
        child: NavigationBar(
          selectedIndex: activeTab,
          onDestinationSelected: (value) => setState(() => tab = value),
          destinations: [
            for (var i = 0; i < titles.length; i++)
              NavigationDestination(
                icon: Icon(icons[i]),
                selectedIcon: Icon(icons[i]),
                label: titles[i],
              ),
          ],
        ),
      ),
    );
  }
}

class _RoleAssistantSheet extends StatefulWidget {
  final String role;
  const _RoleAssistantSheet({required this.role});

  @override
  State<_RoleAssistantSheet> createState() => _RoleAssistantSheetState();
}

class _RoleAssistantSheetState extends State<_RoleAssistantSheet> {
  final _controller = TextEditingController();
  bool _loading = false;
  String? _error;
  String? _answer;

  String get _quickPrompt => switch (widget.role) {
        'DRIVER' => dt('كيف أتابع توصيلاتي أو أزيد فرص الطلبات؟'),
        'VENDOR' => dt('ما حالة طلبات المتجر والمنتجات الآن؟'),
        'ADMIN' => dt('اعرض ملخص الطوابير والطلبات المعلقة الآن'),
        _ => dt('ما حالة طلباتي الحالية؟'),
      };

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _ask([String? preset]) async {
    final text = (preset ?? _controller.text).trim();
    if (preset != null) {
      _controller.text = preset;
    }
    if (text.length < 2 || text.length > 1200) {
      setState(() => _error = dt('اكتب سؤالاً من محرفين على الأقل'));
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final result = await Api.instance.post('/ai/assistant/ask', {
        'message': text,
      });
      if (result is! Map || (result['answer']?.toString().trim().isEmpty ?? true)) {
        throw ApiException(dt('استجابة المساعد غير مكتملة'));
      }
      if (mounted) {
        setState(() => _answer = result['answer'].toString().trim());
      }
    } on ApiException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) {
        setState(
          () => _error = dt('تعذر الاتصال بالمساعد الذكي. تحقق من الإنترنت وحاول مجدداً.'),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(18, 8, 18, bottomInset + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: DarbColors.heroGradient,
                borderRadius: BorderRadius.circular(DarbRadius.xl),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.auto_awesome_rounded, color: DarbColors.lime, size: 22),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          dt('مساعد دَرْب التشغيلي'),
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 17,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      DarbStatusBadge(
                        label: dt('إجابات إرشادية للقراءة فقط'),
                        tone: DarbTone.neutral,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    dt('إرشادات فورية مبنية على بيانات حسابك ودورك دون تعديل تلقائي على الطلبات.'),
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: .80),
                      fontSize: 12,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            ActionChip(
              avatar: Icon(Icons.bolt_rounded, size: 16, color: DarbColors.brandForeground),
              label: Text(_quickPrompt, maxLines: 1, overflow: TextOverflow.ellipsis),
              onPressed: _loading ? null : () => _ask(_quickPrompt),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _controller,
              enabled: !_loading,
              minLines: 2,
              maxLines: 4,
              maxLength: 1200,
              decoration: InputDecoration(
                labelText: dt('اسأل مساعد دَرْب'),
                hintText: dt('اكتب سؤالك هنا...'),
                alignLabelWithHint: true,
              ),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              onPressed: _loading ? null : () => _ask(),
              icon: _loading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.auto_awesome_rounded, size: 18),
              label: Text(_loading ? dt('جارٍ التفكير...') : dt('إرسال السؤال')),
            ),
            if (_error != null) ...[
              const SizedBox(height: 12),
              _ErrorPanel(message: _error!, retry: () => _ask()),
            ],
            if (_answer != null) ...[
              const SizedBox(height: 14),
              DarbSurfaceCard(
                padding: const EdgeInsets.all(16),
                backgroundColor: DarbColors.surfaceAlt,
                child: SelectableText(
                  _answer!,
                  textAlign: TextAlign.start,
                  style: TextStyle(
                    color: DarbColors.ink,
                    fontSize: 13.5,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
