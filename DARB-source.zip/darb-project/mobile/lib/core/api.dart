import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class Api {
  Api._();
  static final Api instance = Api._();
  static const baseUrl = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:3000/api/v1');
  static const _storage = FlutterSecureStorage();
  String? _accessToken;
  String? get accessToken => _accessToken;

  Future<void> restore() async => _accessToken = await _storage.read(key: 'accessToken');
  Future<void> saveTokens(Map<String, dynamic> tokens) async {
    _accessToken = tokens['accessToken'] as String?;
    if (_accessToken != null) await _storage.write(key: 'accessToken', value: _accessToken);
    final refresh = tokens['refreshToken'] as String?;
    if (refresh != null) await _storage.write(key: 'refreshToken', value: refresh);
  }
  Future<void> clear() async {
    _accessToken = null;
    await _storage.deleteAll();
  }
  Future<dynamic> get(String path) => _request('GET', path);
  Future<dynamic> post(String path, Map<String, dynamic> body) => _request('POST', path, body: body);
  Future<dynamic> patch(String path, Map<String, dynamic> body) => _request('PATCH', path, body: body);

  Future<dynamic> _request(String method, String path, {Map<String, dynamic>? body}) async {
    final uri = Uri.parse('$baseUrl$path');
    final headers = <String, String>{'Content-Type': 'application/json', 'Accept': 'application/json'};
    if (_accessToken != null) headers['Authorization'] = 'Bearer $_accessToken';
    late http.Response response;
    try {
      final request = http.Request(method, uri)..headers.addAll(headers);
      if (body != null) request.body = jsonEncode(body);
      final streamed = await request.send().timeout(const Duration(seconds: 20));
      response = await http.Response.fromStream(streamed);
    } catch (_) {
      throw const ApiException('تعذر الاتصال بالخادم. تحقق من الإنترنت وحاول مجدداً.');
    }
    dynamic data;
    try { data = response.body.isEmpty ? null : jsonDecode(response.body); } catch (_) { data = null; }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = data is Map ? (data['message'] is List ? (data['message'] as List).join('\n') : data['message']) : null;
      throw ApiException(message?.toString() ?? 'حدث خطأ (${response.statusCode})');
    }
    return data;
  }
}

class ApiException implements Exception {
  final String message;
  const ApiException(this.message);
  @override
  String toString() => message;
}
