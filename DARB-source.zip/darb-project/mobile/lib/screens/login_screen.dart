import 'package:flutter/material.dart';
import '../core/api.dart';
import 'app_shell.dart';

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState() => _LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController(); final code = TextEditingController(); final name = TextEditingController();
  bool sent = false, busy = false; String? error;
  @override void dispose() { phone.dispose(); code.dispose(); name.dispose(); super.dispose(); }
  Future<void> requestCode() async {
    setState(() { busy = true; error = null; });
    try { await Api.instance.post('/auth/otp/request', {'phone': phone.text.trim()}); setState(() => sent = true); }
    catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  Future<void> verify() async {
    setState(() { busy = true; error = null; });
    try {
      final result = await Api.instance.post('/auth/otp/verify', {'phone': phone.text.trim(), 'code': code.text.trim(), 'name': name.text.trim().isEmpty ? null : name.text.trim(), 'locale': 'ar'});
      await Api.instance.saveTokens(Map<String, dynamic>.from(result['tokens'] as Map));
      if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const AppShell()));
    } catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 440), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Container(height: 86, width: 86, alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xFF142C27), borderRadius: BorderRadius.circular(28)), child: const Text('د', style: TextStyle(color: Colors.white, fontSize: 48, fontWeight: FontWeight.w900))),
    const SizedBox(height: 22), const Text('دَرْب', textAlign: TextAlign.center, style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900, color: Color(0xFF142C27))),
    const SizedBox(height: 6), const Text('كل ما تحتاجه، على طريقك', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 34), Text(sent ? 'أدخل رمز التحقق' : 'سجّل الدخول برقم هاتفك', style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 16), TextField(controller: phone, keyboardType: TextInputType.phone, enabled: !sent, decoration: const InputDecoration(labelText: 'رقم الهاتف السوري', hintText: '09XXXXXXXX', prefixText: '+963 ')),
    if (sent) ...[const SizedBox(height: 12), TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم (اختياري)')), const SizedBox(height: 12), TextField(controller: code, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: 'رمز التحقق المكوّن من 6 أرقام'))],
    if (error != null) ...[const SizedBox(height: 12), Text(error!, style: const TextStyle(color: Colors.red))],
    const SizedBox(height: 18), FilledButton(onPressed: busy ? null : (sent ? verify : requestCode), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54), backgroundColor: const Color(0xFF167A5A)), child: busy ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : Text(sent ? 'تأكيد الدخول' : 'إرسال رمز التحقق')),
    if (sent) TextButton(onPressed: busy ? null : () => setState(() { sent = false; code.clear(); }), child: const Text('تغيير رقم الهاتف')),
    const SizedBox(height: 20), const Text('باستخدامك التطبيق، أنت توافق على شروط الاستخدام وسياسة الخصوصية.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black45))
  ]))))));
}
